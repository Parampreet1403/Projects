#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cmath>

/*
Takes in an array of numbers and the number of elements and computes the mean.
:args: number (int), array (double)
:returns: mean value (double)
*/
double mean(int number, const double *array) {
	double mean{};
	double total{};
	for (int i{}; i < number; i++) {
		total += array[i]; // sums all array elements
	}
	mean = total / number;
	return mean;
}

/*
Takes in an array of numbers and the number of elements and computes the standard deviation.
:args: number (int), array (double), mean (double)
:returns: satndard deviation value (double)
*/
double standard_deviation(int number, double *array, double mean) {
	//double exact_constant{ 0.0204081633 };
	double constant{ (1 / ((double) number - 1)) };
	double total{};
	double x{ sqrt(number) };
	for (int i{}; i < number; i++) {
		total += pow(array[i] - mean, 2); // sums (x_i - mean)^2
	}
	double standard_deviation{ sqrt(constant * total) };
	return standard_deviation;
}

/*
Takes in number of elemts in array and mean of array and computes standard error.
:args: number (int), mean (double)
:returns: satndard error value (double)
*/
double standard_error(int number, double mean) {
	double standard_error{ mean / sqrt(number) };
	return standard_error;
}



int main() {

	std::fstream my_file{};
	std::string file_name{};
	std::cout << "Please enter the name of the file. \n";
	std::cin >> file_name;
	//file_name = "2.txt";

	//opens and validates file
	my_file.open(file_name);
	if (my_file.good()) {
		std::cout << "The file was read successfully.\n";
	}
	else {
		std::cerr << "The file you entered was not found.\nPlease restart the programme.\n";
		exit(1);
	}

	//reads number of valid lines and prints error for rouge words
	int count{};
	double y{};
	std::string s{};
	while (!my_file.eof()) {
		std::getline(my_file, s);
		std::stringstream ss{ s };
		if (ss >> y) {
			count++;
		}
		else {
			
			std::cout << "On line " << count + 1 << " there was a rouge word detected: " << s << "\n";
		}
	}
	my_file.close();
	std::cout << "The number of valid lines: " << count << std::endl;

	//Stores valid values into array
	const int x{count};
	double* my_array = new double[x]{}; //my_array points to x, but "new" deletes the content of x. so an array with 50 elements is created.
	int i{};
	my_file.open(file_name); //re-opens file so it begins reading from begining

	while (!my_file.eof()) {
		std::getline(my_file, s);
		std::stringstream ss{ s };
		if (ss >> y) {
			*(my_array+i) = std::stod(s); //array points to all valid respective lines
			i++;
		}
	}
	my_file.close();

	//prints array
	/*
	for (int counter{}; counter < count; counter++) {
		std::cout << my_array[counter] << std::endl;
	}
	*/

	double mean_number = mean(x, my_array);
	std::cout << "\nThe mean is: " << mean_number << std::endl;

	double  standard_deviation_number = standard_deviation(x, my_array, mean_number);
	std::cout << "\nThe standard deviation is: " << standard_deviation_number << std::endl;

	double standard_error_number = standard_error(x, mean_number);
	std::cout << "\nThe standard error in the mean is: " << standard_error_number << std::endl;
	delete[] my_array;
	return 0;
}
